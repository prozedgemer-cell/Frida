# Frida — Kontrolpanel (18+)

Dansk-first personligt BDSM-flavored kontrolpanel til **Frida** (biologisk mand, tiltalt som kvinde).  
Local-first MVP: React + TypeScript + Vite. Data i `localStorage`. Ingen auth.

> **18+ only.** Indeholder seksuelt / BDSM-indhold. Nødstop og hard limits er indbygget.

## Kør lokalt

```bash
cd frida
npm install
npm run dev
```

Åbn den URL Vite viser (typisk `http://localhost:5173`).

Production build:

```bash
npm run build
npm run preview
```

## Push til GitHub (`prozedgemer-cell/Frida`)

Fra din egen maskine, efter du har pakket zip'en ud:

```bash
# Opret repo på GitHub hvis det ikke findes endnu, eller brug eksisterende
git clone git@github.com:prozedgemer-cell/Frida.git
cd Frida

# Kopiér indholdet fra denne MVP ind i repoet (behold .git)
# Eksempel hvis zip er pakket ud til ./frida-source :
rsync -av --exclude node_modules --exclude dist ./frida-source/ ./

npm install
npm run build
git add .
git commit -m "Initial Frida kontrolpanel MVP"
git push -u origin main
```

Hvis repoet er tomt, kan du også `git init` i projektmappen, tilføje remote, og pushe.

## Hvad er med i MVP

- **18+ gate** ved første besøg
- **Profil**: navn låst til Frida, fake breast cup-størrelse, soft/hard intensitet, soft/hard-dag, theme packs, hard limits
- **Dashboard**: tydelig undertøjs-beording, challenges, IRL/gaming-kontekst, stort **nødstop**
- **Auto undertøj**: vægtet motor (tid, hverdag/weekend, IRL-status, valgfrit spil, intensitet, themes) — dagens valg gemmes, reroll muligt
- **Challenge-motor**: ~118 danske skabeloner med tags/themes; anatomi-respekt (ingen vaginal-use; semen-opsamling tilladt ærligt); complete / skip / fail-log
- **Themes** (toggle): BDSM, clothing/underwear, sex, IRL, porn, anime, hentai, fantasy roleplay
- Mørk sort/rød æstetik, mobilvenlig

## Tilføj challenge-skabeloner

Rediger `src/data/challenges.ts` og tilføj objekter til `CHALLENGE_TEMPLATES`:

```ts
{
  id: 'ch-mit-01',
  titleDa: 'Kort titel',
  bodyDa: 'Ordre til Frida. Brug {breastSize}, {underwear}, {game}, {irl} efter behov.',
  tags: ['min-tag'],
  themes: ['bdsm', 'clothing'],
  intensity: ['soft', 'hard'],
  // allowsSemenCollection: true,  // kun hvis ærlig anatomi / opsamling
  // hardLimitKeys: ['blod'],
  // minDurationMin: 5,
  // vars: ['breastSize'],
}
```

**Regler**

- Skriv på dansk, tiltale **Frida**
- Ingen vagina-/vaginal-tease challenges (undtagen eksplicit semen-opsamling med ærlig anatomi)
- Respekter hard limits via `hardLimitKeys`

### Hvordan det skalerer mod titusinder

Antal skabeloner × aktive theme packs × soft/hard × variabel-udfyldning (`breastSize`, `underwear`, `game`, `irl`) × kontekst (tid/IRL) giver et stort kombinatorisk rum.  
Med ~120 skabeloner og 8 themes lander ordensstørrelsen allerede i **tusinder–titusinder** unikke konkrete tekster — uden at hardkode hver variant. Tilføj flere skabeloner/tags for at vokse videre.

Undertøjskatalog: `src/data/underwear.ts`.

## Out of scope (næste skridt)

- Rigtige game APIs / automatisk detektion af spil
- Multi-user / cloud sync
- Native apps
- Konti / auth

## Sikkerhed

- Nødstop pauser challenges og fryser nye ordrer
- Hard limits filtrerer skabeloner
- Soft-dag begrænser til soft-capable challenges
- Privat: alt ligger lokalt i browseren

## Licens / privat

Privat personligt projekt. Del ikke andres data. Ingen screenshots til deling hvis det bryder dine egne limits.
