import { AgeGate } from './components/AgeGate';
import { Dashboard } from './components/Dashboard';
import { useFridaState } from './hooks/useFridaState';

export default function App() {
  const api = useFridaState();

  if (!api.state.profile.ageVerified) {
    return <AgeGate onConfirm={api.verifyAge} />;
  }

  return <Dashboard api={api} />;
}
